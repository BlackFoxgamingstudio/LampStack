<?php
session_start();

// get_gold - function to return a random number
// between the passed in min and max parameters
function get_gold($min, $max)
{
	return rand($min, $max);
}

// Check if restart-form was submitted
// If it is, unset the $_SESSION variable
if (isset($_POST['action']) && $_POST['action'] == 'restart_form')
{
	$_SESSION = array();
	header("Location: index.php");
}

// Initially check if the gold count is stored
// in the session and if not, set it to 0
if (!isset($_SESSION['gold_count'])) {
	$_SESSION['gold_count'] = 0;
}

// Check which building form has been submitted
// and set the appropriate session variables
if (isset($_POST['building']))
{
	$building = $_POST['building'];
	$gold_count = 0;
	$activity = array();
	$class="green";

	switch ($building) 
	{
		case 'farm':
			$gold_count = get_gold(10, 20);
		break;
		
		case 'cave':
			$gold_count = get_gold(5, 10);
		break;

		case 'house':
			$gold_count = get_gold(2, 5);
		break;

		case 'casino':
			$percent = rand(0, 100);

			if ($percent <= 70) 
			{
				$gold_count = get_gold(-50, -1);
				$class = "red";
				$message = "Ouch";
			}
			else 
			{
				$gold_count = get_gold(1, 50);
				$class = "green";
				$message = "Nice";
			}
			
		break;
	}

	// $_SESSION['activity'] is an array that holds all of the activity
	// log information. We check if there is already data in this array
	// and if so store it in the local $activity variable that is later appended to
	if (isset($_SESSION['activity'])) 
		// store a local copy of the current activity log array
		$activity = $_SESSION['activity'];
	else
		$activity = array();
	
	// Set the current gold count and build the activity log message
	// to be return in the session to index.php
	$_SESSION['gold_count'] += $gold_count;
	$_SESSION['activity'][] = '<span class="' . $class . '"> You entered a ' . $building . ' and earned ' . $gold_count . ' golds. ' . 
							(($building == 'casino') ? '... '. $message .'.. ' : '') . '   (' . date('M d, Y h:ia') . ')</span><br>';
	
	header("Location: index.php");
	exit();
}
?>