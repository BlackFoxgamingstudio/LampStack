<tr class='task<?= $id; ?>'>
	<td>
		<button class='btn btn-info edit'>Edit</button> 
		<input  class='status' <?= $class; ?> type='checkbox' name='task_id' value='<?= $id; ?>'> 
		<strong class='<?= $class; ?>'><?= $name; ?></strong>
	</td>
</tr>