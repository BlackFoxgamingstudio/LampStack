<?php
/**
 * This file represents an example of the code that themes would use to register
 * the required plugins.
 *
 * @package	   TGM-Plugin-Activation
 * @subpackage Plugins
 * @author	   Thomas Griffin <thomas@thomasgriffinmedia.com>
 * @author	   Gary Jones <gamajo@gamajo.com>
 * @copyright  Copyright (c) 2012, Thomas Griffin
 * @license	   http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       https://github.com/thomasgriffin/TGM-Plugin-Activation
 */

/**
 * Include the TGM_Plugin_Activation class.
 */
require_once THEME_DIR . '/inc/libs/tgm/class-tgm-plugin-activation.php';

add_action( 'tgmpa_register', 'tokopress_register_required_plugins' );
function tokopress_register_required_plugins() {

	/**
	 * Array of plugin arrays. Required keys are name and slug.
	 * If the source is NOT from the .org repo, then source is also required.
	 */
	$plugins = array(

		/* Required Plugin */
		array(
			'name'		=> 'The Events Calendar',
			'slug'		=> 'the-events-calendar',
			'required'	=> true,
		),

		/* Recommended Plugin */
		array(
			'name'     	=> 'Visual Composer',
			'slug'     	=> 'js_composer',
			'source'   	=> get_template_directory() . '/inc/plugins/js_composer-v4.4.2.zip',
			'version' 	=> '4.4.2',
			'required' 	=> false,
		),

		array(
			'name'     	=> 'Eventica Visual Composer & Shortcodes',
			'slug'     	=> 'eventica-visual-composer-shortcode',
			'source'   	=> get_template_directory() . '/inc/plugins/eventica-visual-composer-shortcode-v1.0.zip',
			'version' 	=> '1.0',
			'required' 	=> false,
		),

		array(
			'name'		=> 'MailChimp for WordPress',
			'slug'		=> 'mailchimp-for-wp',
			'required'	=> false,
		),

		array(
			'name'		=> 'WooCommerce',
			'slug'		=> 'woocommerce',
			'required'	=> false,
		),

		array(
			'name'     => 'Testimonials Plugin For Eventica',
			'slug'     => 'eventica-testimonials',
			'source'   => get_template_directory() .'/inc/plugins/eventica-testimonials_v1.0.zip',
			'required' => false
		),
		
		array(
			'name'		=> 'WordPress Importer',
			'slug'		=> 'wordpress-importer',
			'source'   	=> get_template_directory() . '/inc/plugins/wordpress-importer-v2.0.zip',
			'version' 	=> '2.0',
			'required' 	=> false,
		),
		
		array(
			'name'		=> 'Widget Importer Exporter',
			'slug'		=> 'widget-importer-exporter',
			'required'	=> false,
		),
		
		array(
			'name'		=> 'Regenerate Thumbnails',
			'slug'		=> 'regenerate-thumbnails',
			'required'	=> false,
		),

		// array(
		// 	'name'		=> 'WP Retina 2x',
		// 	'slug'		=> 'wp-retina-2x',
		// 	'required'	=> false,
		// )

	);

	// Text Domain
	$theme_text_domain = 'tokopress';

	/**
	 * Array of configuration settings. Amend each line as needed.
	 * If you want the default strings to be available under your own theme domain,
	 * leave the strings uncommented.
	 * Some of the strings are added into a sprintf, so see the comments at the
	 * end of each line for what each argument will be.
	 */
	$config = array(
		'domain'       		=> $theme_text_domain,         	// Text domain - likely want to be the same as your theme.
		'default_path' 		=> '',                         	// Default absolute path to pre-packaged plugins
		'parent_menu_slug' 	=> 'themes.php', 				// Default parent menu slug
		'parent_url_slug' 	=> 'themes.php', 				// Default parent URL slug
		'menu'         		=> 'install-required-plugins', 	// Menu slug
		'has_notices'      	=> true,                       	// Show admin notices or not
		'is_automatic'    	=> true,					   	// Automatically activate plugins after installation or not
		'message' 			=> '',							// Message to output right before the plugins table
		'strings'      		=> array(
			'page_title'                       			=> __( 'Install Required Plugins', 'tokopress' ),
			'menu_title'                       			=> __( 'Install Plugins', 'tokopress' ),
			'installing'                       			=> __( 'Installing Plugin: %s', 'tokopress' ), // %1$s = plugin name
			'oops'                             			=> __( 'Something went wrong with the plugin API.', 'tokopress' ),
			'notice_can_install_required'     			=> _n_noop( 'This theme requires the following plugin: %1$s.', 'This theme requires the following plugins: %1$s.', 'tokopress' ), // %1$s = plugin name(s)
			'notice_can_install_recommended'			=> _n_noop( 'This theme recommends the following plugin: %1$s.', 'This theme recommends the following plugins: %1$s.', 'tokopress' ), // %1$s = plugin name(s)
			'notice_cannot_install'  					=> _n_noop( 'Sorry, but you do not have the correct permissions to install the %s plugin. Contact the administrator of this site for help on getting the plugin installed.', 'Sorry, but you do not have the correct permissions to install the %s plugins. Contact the administrator of this site for help on getting the plugins installed.', 'tokopress' ), // %1$s = plugin name(s)
			'notice_can_activate_required'    			=> _n_noop( 'The following required plugin is currently inactive: %1$s.', 'The following required plugins are currently inactive: %1$s.', 'tokopress' ), // %1$s = plugin name(s)
			'notice_can_activate_recommended'			=> _n_noop( 'The following recommended plugin is currently inactive: %1$s.', 'The following recommended plugins are currently inactive: %1$s.', 'tokopress' ), // %1$s = plugin name(s)
			'notice_cannot_activate' 					=> _n_noop( 'Sorry, but you do not have the correct permissions to activate the %s plugin. Contact the administrator of this site for help on getting the plugin activated.', 'Sorry, but you do not have the correct permissions to activate the %s plugins. Contact the administrator of this site for help on getting the plugins activated.', 'tokopress' ), // %1$s = plugin name(s)
			'notice_ask_to_update' 						=> _n_noop( 'The following plugin needs to be updated to its latest version to ensure maximum compatibility with this theme: %1$s.', 'The following plugins need to be updated to their latest version to ensure maximum compatibility with this theme: %1$s.', 'tokopress' ), // %1$s = plugin name(s)
			'notice_cannot_update' 						=> _n_noop( 'Sorry, but you do not have the correct permissions to update the %s plugin. Contact the administrator of this site for help on getting the plugin updated.', 'Sorry, but you do not have the correct permissions to update the %s plugins. Contact the administrator of this site for help on getting the plugins updated.', 'tokopress' ), // %1$s = plugin name(s)
			'install_link' 					  			=> _n_noop( 'Begin installing plugin', 'Begin installing plugins', 'tokopress' ),
			'activate_link' 				  			=> _n_noop( 'Activate installed plugin', 'Activate installed plugins', 'tokopress' ),
			'return'                           			=> __( 'Return to Required Plugins Installer', 'tokopress' ),
			'plugin_activated'                 			=> __( 'Plugin activated successfully.', 'tokopress' ),
			'complete' 									=> __( 'All plugins installed and activated successfully. %s', 'tokopress' ), // %1$s = dashboard link
			'nag_type'									=> 'updated' // Determines admin notice type - can only be 'updated' or 'error'
		)
	);

	tgmpa( $plugins, $config );

}

/* Set Visual Composer as Theme part and disable Visual Composer Updater */
if ( function_exists( 'vc_set_as_theme' ) ) 
	vc_set_as_theme( true );


add_filter('vc_load_default_templates','tokopress_load_vc_templates');
function tokopress_load_vc_templates( $args ) {
	$args2 = array ( 
		array(
			'name'=> '1. '.__('Eventica - Home','tokopress'),
			'image_path'=> THEME_URI . '/img/vc-homepage.png', 
			'content'=>'[vc_row full_width="stretch_row_content_no_spaces" css=".vc_custom_1425161144334{margin-bottom: 0px !important;}"][vc_column width="1/1"][eventica_events_slider per_page="4" container="yes"][/vc_column][/vc_row][vc_row css=".vc_custom_1425351223401{margin-bottom: 0px !important;}"][vc_column width="1/1"][eventica_events_search][/vc_column][/vc_row][vc_row css=".vc_custom_1425353909117{margin-bottom: 0px !important;padding-top: 30px !important;background-color: #cccccc !important;}" full_width="stretch_row"][vc_column width="1/1"][eventica_upcoming_events numbers="3" columns="3" columns_tablet="2" title_hide="no" title_color="#ffffff"][/vc_column][/vc_row][vc_row css=".vc_custom_1425351865698{margin-bottom: 0px !important;}"][vc_column width="1/3" css=".vc_custom_1425353892342{padding-top: 30px !important;}"][eventica_recent_posts numbers="3" columns="1" columns_tablet="2" title_hide="no"][/vc_column][vc_column width="2/3" css=".vc_custom_1425351892447{margin-bottom: 0px !important;}"][eventica_featured_event title_hide="no" columns="1"][eventica_subscribe_form][/vc_column][/vc_row][vc_row css=".vc_custom_1425351905476{margin-bottom: 0px !important;}"][vc_column width="1/1"][eventica_testimonials numbers="" title_hide="no" title_text=""][/vc_column][/vc_row][vc_row css=".vc_custom_1425351917990{margin-bottom: 0px !important;}"][vc_column width="1/1"][eventica_brand_sponsors title_hide="no"][/vc_column][/vc_row]', 
		),
	);
	return array_merge( $args, $args2 );
}
