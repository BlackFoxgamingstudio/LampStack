<?php if( ! class_exists( 'TribeEvents' ) ) : ?>
	<p class="nothing-plugins"><?php _e( 'Please install <strong>The Event Calendar</strong> plugin.', 'tokopress' ); ?></p>
	<?php return; ?>
<?php endif; ?>

<?php
$ids = of_get_option( 'tokopress_home_slider_ids' );
$args = array(
	'post_status'=>'publish',
	'post_type'=>array(TribeEvents::POSTTYPE),
	);
if ( ! empty( $ids ) ) {
	$ids = explode( ",", $ids );
	$args['post__in'] = $ids;
	$args['orderby'] = 'post__in';
}
else {
	$args['posts_per_page'] = 4;
	$args['eventDisplay'] = 'list';
	$args['orderby'] = 'event_date';
	$args['order'] = 'ASC';
}
$the_slider_events = new WP_Query( $args );
?>

<?php if( $the_slider_events->have_posts() ) : ?>
<?php $class = $the_slider_events->post_count > 1 ? 'home-slider-events-active' : ''; ?>
<div class="home-slider-events clearfix <?php echo esc_attr( $class ); ?>">
	<?php while ( $the_slider_events->have_posts() ) : ?>
		<?php $the_slider_events->the_post(); ?>
		<?php $img = wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'full' ); ?>
		<?php if ( $img ) : ?>
			<div class="slide-event item" style="background-image:url(<?php echo esc_url($img); ?>)">
		<?php else : ?>
			<div class="slide-event item">
		<?php endif; ?>
			<div class="container">
			<div class="row">
			<div class="col-sm-6 col-md-5 col-lg-4">
			<div class="slide-event-detail">
				<h2 class="slide-event-title">
					<a class="url" href="<?php echo tribe_get_event_link() ?>" title="<?php the_title() ?>" rel="bookmark">
						<?php the_title() ?>
					</a>
				</h2>
				<div class="slide-event-cta">
					<div class="slide-event-cta-date">
						<span class="mm"><?php echo tribe_get_start_date( null, false, 'F' ) ?></span>
						<span class="dd"><?php echo tribe_get_start_date( null, false, 'd' ) ?></span>
						<span class="yy"><?php echo tribe_get_start_date( null, false, 'Y' ) ?></span>
					</div>
					<a class="btn" href="<?php echo tribe_get_event_link() ?>">
						<?php if( "" != of_get_option( 'tokopress_home_slide_button' ) ) : ?>
							<?php echo esc_attr( of_get_option( 'tokopress_home_slide_button' ) ); ?>
						<?php else : ?>
							<?php _e( 'Detail', 'tokopress' ); ?>
						<?php endif; ?>
					</a>
				</div>
				<div class="slide-event-venue">
					<div class="slide-event-venue-name">
						<?php echo tribe_get_venue(); ?>
					</div>
					<?php if ( tribe_address_exists() ) : ?>
						<div class="slide-event-venue-address">
							<?php echo tribe_get_full_address(); ?>
						</div>
					<?php endif; ?>
				</div>
			</div>
			</div>
			</div>
			</div>
		</div>
	<?php endwhile; ?>
</div>
<?php endif; ?>
<?php wp_reset_postdata(); ?>