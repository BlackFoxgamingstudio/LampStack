<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

add_action( 'get_header', 'tokopress_events_action_get_header' );
function tokopress_events_action_get_header() {

	/* Hide Event Calendar Pro Related Events, use our theme */
	if ( class_exists('TribeEventsPro') ) {
		tokopress_remove_filter_class( 'tribe_events_single_event_after_the_meta', 'TribeEventsPro', 'register_related_events_view', 10 );
	}

	/* Hide Event Calendar Pro Additional Fields, use our theme */
	if ( class_exists('TribeEventsPro_SingleEventMeta') ) {
		tokopress_remove_filter( 'tribe_events_single_event_meta_primary_section_end', 'additional_fields', 10 );
	}
}

add_filter( 'tribe_meta_event_tags', 'overide_markup_tags', 10, 3 );
function overide_markup_tags( $list, $label, $separator ) {
	$list = get_the_term_list( get_the_ID(), 'post_tag', '<tr><th>' . $label . '</th><td class="tribe-event-tags">', $separator, '</td></tr>' );

	return $list;
}
