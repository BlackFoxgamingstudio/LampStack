		<?php if( !of_get_option( 'tokopresss_disable_footer_widget' ) )
			get_template_part( 'block-footer-widget' ); ?>

		<?php if( !of_get_option( 'tokopresss_disable_footer_buttom' ) )
			get_template_part( 'block-footer-credit' ); ?>

		</div>
		<div class="sb-slidebar sb-left"></div>
		<?php wp_footer(); ?>
	</body>
</html>