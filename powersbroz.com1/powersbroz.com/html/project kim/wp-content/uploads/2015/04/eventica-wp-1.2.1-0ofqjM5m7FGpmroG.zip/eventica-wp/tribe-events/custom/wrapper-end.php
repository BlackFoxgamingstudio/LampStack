<?php
global $tp_sidebar, $tp_content_class, $tp_title;
?>

					<?php tribe_events_after_html(); ?>
				</div> <!-- #tribe-events-pg-template -->

			</div>

			<?php if ( $tp_sidebar ) get_sidebar('event'); ?>

		</div>
	</div>

</div>
