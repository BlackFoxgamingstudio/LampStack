<?php
/**
 * Single Event Meta (Venue) Template
 *
 * Override this template in your own theme by creating a file at:
 * [your-theme]/tribe-events/modules/meta/venue.php
 *
 * @package TribeEventsCalendar
 */

if ( ! tribe_get_venue_id() ) {
	return;
}

$venue_id = tribe_get_venue_id();

$venue_page = '';
if ( class_exists( 'Tribe_Events_Pro_Single_Venue_Template' ) ) {
	$venue_page = get_permalink( $venue_id );
}

$phone = function_exists( 'tribe_get_phone' ) ? tribe_get_phone() : '';
$website_url = tribe_get_event_meta( $venue_id, '_VenueURL', true );
?>

<div class="tribe-events-meta-group tribe-events-meta-group-venue">
	<h3 class="tribe-events-single-section-title"> <?php _e( 'Venue', 'tokopress' ) ?> </h3>
	<div class="meta-inner">
		<?php do_action( 'tribe_events_single_meta_venue_section_start' ) ?>

		<p class="author fn org">
			<?php if ( ! empty( $venue_page ) ): ?>
				<a href="<?php echo esc_url( $venue_page ); ?>">
					<?php echo tribe_get_venue() ?> 
				</a>
			<?php else : ?>
				<?php echo tribe_get_venue() ?> 
			<?php endif ?>
		</p>

		<?php
		// Do we have an address?
		$address = tribe_address_exists() ? tribe_get_full_address() : '';

		// Do we have a Google Map link to display?
		$gmap_link = tribe_show_google_map_link() ? tribe_get_map_link_html() : '';
		$gmap_link = apply_filters( 'tribe_event_meta_venue_address_gmap', $gmap_link );
		?>

		<?php if ( ! empty( $address ) ) : ?>
			<address class="tribe-events-address">
				<?php echo wp_kses_data( $address ); ?>
			</address>
			<p class="location">
				<?php echo wp_kses_data( $gmap_link ); ?>
			</p>
		<?php endif ?>

		<?php if ( ! empty( $phone ) ): ?>
			<p class="label"> <?php _e( 'Phone:', 'tokopress' ) ?> </p>
			<p class="tel"> <?php echo wp_kses_data( $phone ); ?> </p>
		<?php endif ?>

		<?php if ( ! empty( $website_url ) ): ?>
			<p> 
				<a href="<?php echo esc_url( $website_url ); ?>">
					<?php _e( 'Visit Venue Website', 'tokopress' ); ?>
				</a> 
			</p>
		<?php endif ?>

		<?php do_action( 'tribe_events_single_meta_venue_section_end' ) ?>
	</div>
</div>