<?php
/**
 * Theme Customizer
 */

add_action( 'customize_register', 'tokopress_customize_reposition', 20 );
function tokopress_customize_reposition( $wp_customize ) {
	$wp_customize->get_section( 'background_image' )->priority = 140;
	$wp_customize->get_section( 'background_image' )->title = __( 'Background', 'tokopress' );
	$wp_customize->get_control( 'background_color' )->section = 'background_image';

	$wp_customize->get_section( 'header_image' )->priority = 160;
	$wp_customize->get_section( 'header_image' )->title = __( 'Header (Page Title)', 'tokopress' );
	$wp_customize->remove_control('header_textcolor');
	
}

/**
 * Header (Top)
 */
add_filter( 'tokopress_customizer_sections', 'tokopress_customize_headertop_section' );
function tokopress_customize_headertop_section( $tk_sections ) {
	$tk_sections[] = array(
			'slug'		=> 'tokopress_headertop_section',
			'label'		=> __( 'Header (Top)', 'tokopress' ),
			'priority'	=> 150,
		);

	return $tk_sections;
}
add_filter( 'tokopress_customizer_data', 'tokopress_customize_headertop_colors' );
function tokopress_customize_headertop_colors( $tk_colors ) {
	$tk_colors[] = array( 
		'slug'		=> 'tokopress_headertop_bg', 
		'default'	=> '', 
		'label'		=> __( 'Header Background', 'tokopress' ),
		'section'	=> 'tokopress_headertop_section',
		'transport'	=> 'postMessage',
		'type' 		=> 'color',
		'selector'	=> '.site-header, .header-menu.sf-menu li a',
		'property'	=> 'background-color'
	);

	$tk_colors[] = array( 
		'slug'		=> 'tokopress_headertop_logo_bg', 
		'default'	=> '', 
		'label'		=> __( 'Logo Background', 'tokopress' ),
		'section'	=> 'tokopress_headertop_section',
		'transport'	=> 'postMessage',
		'type' 		=> 'color',
		'selector'	=> '.site-branding',
		'property'	=> 'background-color'
	);

	$tk_colors[] = array( 
		'slug'		=> 'tokopress_headertop_logo_color', 
		'default'	=> '', 
		'label'		=> __( 'Logo Text Color', 'tokopress' ),
		'section'	=> 'tokopress_headertop_section',
		'transport'	=> 'postMessage',
		'type' 		=> 'color',
		'selector'	=> '.site-branding a, .site-logo p',
		'property'	=> 'color'
	);

	$tk_colors[] = array( 
		'slug'		=> 'tokopress_headertop_menu_color', 
		'default'	=> '', 
		'label'		=> __( 'Menu Color', 'tokopress' ),
		'section'	=> 'tokopress_headertop_section',
		'transport'	=> 'postMessage',
		'type' 		=> 'color',
		'selector'	=> '.site-header, .header-menu.sf-menu li a, .mobile-menu a, .mobile-menu a:visited',
		'property'	=> 'color'
	);

	$tk_colors[] = array( 
		'slug'		=> 'tokopress_headertop_menu_color_hover', 
		'default'	=> '', 
		'label'		=> __( 'Menu Color', 'tokopress' ),
		'section'	=> 'tokopress_headertop_section',
		'transport'	=> 'postMessage',
		'type' 		=> 'color',
		'selector'	=> '.header-menu.sf-menu li a:hover, .mobile-menu a:hover',
		'property'	=> 'color'
	);

	$tk_colors[] = array( 
		'slug'		=> 'tokopress_headertop_menu_color_hover', 
		'default'	=> '', 
		'label'		=> __( 'Menu Color (Hover)', 'tokopress' ),
		'section'	=> 'tokopress_headertop_section',
		'transport'	=> 'postMessage',
		'type' 		=> 'color',
		'selector'	=> '.header-menu .sub-menu li a:hover',
		'property'	=> 'color'
	);

	$tk_colors[] = array( 
		'slug'		=> 'tokopress_headertop_submenu_bg', 
		'default'	=> '', 
		'label'		=> __( 'Submenu Background', 'tokopress' ),
		'section'	=> 'tokopress_headertop_section',
		'transport'	=> 'postMessage',
		'type' 		=> 'color',
		'selector'	=> '.header-menu .sub-menu li a',
		'property'	=> 'background-color'
	);

	$tk_colors[] = array( 
		'slug'		=> 'tokopress_headertop_submenu_bg_hover', 
		'default'	=> '', 
		'label'		=> __( 'Submenu Background (Hover)', 'tokopress' ),
		'section'	=> 'tokopress_headertop_section',
		'transport'	=> 'postMessage',
		'type' 		=> 'color',
		'selector'	=> '.header-menu .sub-menu li a:hover',
		'property'	=> 'background-color'
	);

	return $tk_colors;
}

/**
 * Header (Page Title)
 */
add_filter( 'tokopress_customizer_data', 'tokopress_customize_header_colors' );
function tokopress_customize_header_colors( $tk_colors ) {
	$tk_colors[] = array( 
		'slug'		=> 'tokopress_header_bg', 
		'default'	=> '', 
		'label'		=> __( 'Page Title Background', 'tokopress' ),
		'section'	=> 'header_image',
		'transport'	=> 'postMessage',
		'type' 		=> 'color',
		'selector'	=> '.page-title',
		'property'	=> 'background-color'
	);

	$tk_colors[] = array( 
		'slug'		=> 'tokopress_header_color', 
		'default'	=> '', 
		'label'		=> __( 'Page Title Color', 'tokopress' ),
		'section'	=> 'header_image',
		'transport'	=> 'postMessage',
		'type' 		=> 'color',
		'selector'	=> '.page-title, .page-title h1',
		'property'	=> 'color'
	);

	$tk_colors[] = array( 
		'slug'		=> 'tokopress_header_breadcrumb_color', 
		'default'	=> '', 
		'label'		=> __( 'Breadcrumb Color', 'tokopress' ),
		'section'	=> 'header_image',
		'transport'	=> 'postMessage',
		'type' 		=> 'color',
		'selector'	=> '.page-title .breadcrumb, .page-title .breadcrumb a',
		'property'	=> 'color'
	);

	return $tk_colors;
}

/**
 * Footer Widget
 */
add_filter( 'tokopress_customizer_sections', 'tokopress_customize_footerwidget_section' );
function tokopress_customize_footerwidget_section( $tk_sections ) {
	$tk_sections[] = array(
			'slug'		=> 'tokopress_footerwidget_section',
			'label'		=> __( 'Footer Widget', 'tokopress' ),
			'priority'	=> 170,
		);

	return $tk_sections;
}
add_filter( 'tokopress_customizer_data', 'tokopress_customize_footerwidget_colors' );
function tokopress_customize_footerwidget_colors( $tk_colors ) {
	$tk_colors[] = array( 
		'slug'		=> 'tokopress_footerwidget_bg', 
		'default'	=> '', 
		'label'		=> __( 'Footer Widget Background', 'tokopress' ),
		'section'	=> 'tokopress_footerwidget_section',
		'transport'	=> 'postMessage',
		'type' 		=> 'color',
		'selector'	=> '#footer-widget',
		'property'	=> 'background-color'
	);

	$tk_colors[] = array( 
		'slug'		=> 'tokopress_footerwidget_color', 
		'default'	=> '', 
		'label'		=> __( 'Footer Widget Color', 'tokopress' ),
		'section'	=> 'tokopress_footerwidget_section',
		'transport'	=> 'postMessage',
		'type' 		=> 'color',
		'selector'	=> '#footer-widget, #footer-widget .widget .widget-inner, #footer-widget .widget.widget_recent_posts ul li .tp-entry-date, #footer-widget .widget.widget_upcoming_events ul li .tp-entry-date, #footer-widget .widget.widget_past_events ul li .tp-entry-date',
		'property'	=> 'color',
	);

	$tk_colors[] = array( 
		'slug'		=> 'tokopress_footerwidget_link_color', 
		'default'	=> '', 
		'label'		=> __( 'Footer Widget Link Color', 'tokopress' ),
		'section'	=> 'tokopress_footerwidget_section',
		'transport'	=> 'postMessage',
		'type' 		=> 'color',
		'selector'	=> '#footer-widget a',
		'property'	=> 'color'
	);

	$tk_colors[] = array( 
		'slug'		=> 'tokopress_footerwidget_title_color', 
		'default'	=> '', 
		'label'		=> __( 'Footer Widget Title Color', 'tokopress' ),
		'section'	=> 'tokopress_footerwidget_section',
		'transport'	=> 'postMessage',
		'type' 		=> 'color',
		'selector'	=> '#footer-widget .widget .widget-title',
		'property'	=> 'color'
	);

	$tk_colors[] = array( 
		'slug'		=> 'tokopress_footer_widget_border_color', 
		'default'	=> '', 
		'priority'	=> 5, 
		'label'		=> __( 'Footer Widget Border Color', 'tokopress' ),
		'section'	=> 'tokopress_footerwidget_section',
		'transport'	=> 'postMessage',
		'type' 		=> 'color',
		'selector'	=> '#footer-widget .widget.widget_recent_posts ul li, #footer-widget .widget.widget_upcoming_events ul li, #footer-widget .widget.widget_past_events ul li',
		'property'	=> 'border-color'
	);

	$tk_colors[] = array( 
		'slug'		=> 'tokopress_footer_widget_border_top_color', 
		'default'	=> '', 
		'priority'	=> 6, 
		'label'		=> __( 'Footer Widget Border Top Color', 'tokopress' ),
		'section'	=> 'tokopress_footer_widget_section',
		'transport'	=> 'postMessage',
		'type' 		=> 'color',
		'selector'	=> '.footer-widgets',
		'property'	=> 'border-top-color'
	);

	return $tk_colors;
}

/**
 * Footer Credit
 */
add_filter( 'tokopress_customizer_sections', 'tokopress_customize_footercredit_section' );
function tokopress_customize_footercredit_section( $tk_sections ) {
	$tk_sections[] = array(
			'slug'		=> 'tokopress_footercredit_section',
			'label'		=> __( 'Footer Credit', 'tokopress' ),
			'priority'	=> 180,
		);

	return $tk_sections;
}
add_filter( 'tokopress_customizer_data', 'tokopress_customize_footercredit_color' );
function tokopress_customize_footercredit_color( $tk_colors ) {
	$tk_colors[] = array( 
		'slug'		=> 'tokopress_footercredit_bg', 
		'default'	=> '', 
		'priority'	=> 1, 
		'label'		=> __( 'Footer Credit Background', 'tokopress' ),
		'section'	=> 'tokopress_footercredit_section',
		'transport'	=> 'postMessage',
		'type' 		=> 'color',
		'selector'	=> '#footer-block',
		'property'	=> 'background-color'
	);

	$tk_colors[] = array( 
		'slug'		=> 'tokopress_footercredit_color', 
		'default'	=> '', 
		'priority'	=> 2, 
		'label'		=> __( 'Footer Credit Color', 'tokopress' ),
		'section'	=> 'tokopress_footercredit_section',
		'transport'	=> 'postMessage',
		'type' 		=> 'color',
		'selector'	=> '#footer-block, #footer-block .footer-credit p',
		'property'	=> 'color'
	);

	$tk_colors[] = array( 
		'slug'		=> 'tokopress_footercredit_link_color', 
		'default'	=> '', 
		'priority'	=> 3, 
		'label'		=> __( 'Footer Credit Link Color', 'tokopress' ),
		'section'	=> 'tokopress_footercredit_section',
		'transport'	=> 'postMessage',
		'type' 		=> 'color',
		'selector'	=> '#footer-block, #footer-block #footer-menu #secondary-menu ul.footer-menu li a, #footer-block #footer-menu ul#social-icon li a, #footer-block .footer-credit p a',
		'property'	=> 'color'
	);

	$tk_colors[] = array( 
		'slug'		=> 'tokopress_footercredit_link_color_hover', 
		'default'	=> '', 
		'priority'	=> 3, 
		'label'		=> __( 'Footer Credit Link Color (Hover)', 'tokopress' ),
		'section'	=> 'tokopress_footercredit_section',
		'transport'	=> 'postMessage',
		'type' 		=> 'color',
		'selector'	=> '#footer-block #footer-menu #secondary-menu ul.footer-menu li a:hover',
		'property'	=> 'color'
	);

	return $tk_colors;
}
