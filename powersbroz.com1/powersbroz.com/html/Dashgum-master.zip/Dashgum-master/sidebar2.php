<li class="mt">
                      <a href="index2.php">
                          <i class="fa fa-dashboard"></i>
                          <span>View All Questions</span>
                      </a>
                  </li>
				  
				  <li class="mt">
                      <a href="index2.php">
                          <i class="fa fa-dashboard"></i>
                          <span>Mark Questions as spam</span>
                      </a>
                  </li><li class="mt">
                      <a href="index2.php">
                          <i class="fa fa-dashboard"></i>
                          <span>Question status update</span>
                      </a>
                  </li><li class="mt">
                      <a  href="index2.php">
                          <i class="fa fa-dashboard"></i>
                          <span>Add status</span>
                      </a>
                  </li>
				  <li class="mt">
                      <a  href="index2.php">
                          <i class="fa fa-dashboard"></i>
                          <span>Upload Answer</span>
                      </a>
                  </li>
                <li class="mt">
                      <a href="index2.php">
                          <i class="fa fa-dashboard"></i>
                          <span>Divert Question to tutors</span>
                      </a>
                  </li>
				    <li class="mt">
                      <a  href="index3.php">
                          <i class="fa fa-dashboard"></i>
                          <span>Add Trigger Personality</span>
                      </a>
                  </li>
				  <li class="mt">
                      <a  href="index3.php">
                          <i class="fa fa-dashboard"></i>
                          <span>Add Triggers</span>
                      </a>
         </li>