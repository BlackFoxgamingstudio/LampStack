<li class="mt">
                      <a href="index1.php">
                          <i class="fa fa-dashboard"></i>
                          <span>Ask Question</span>
                      </a>
                  </li>
				  
				  <li class="mt">
                      <a href="index1.php">
                          <i class="fa fa-dashboard"></i>
                          <span>View My Questions</span>
                      </a>
                  </li><li class="mt">
                      <a href="index1.php">
                          <i class="fa fa-dashboard"></i>
                          <span>Question status</span>
                      </a>
                  </li><li class="mt">
                      <a  href="index1.php">
                          <i class="fa fa-dashboard"></i>
                          <span>View Answers</span>
                      </a>
                  </li>
				  <li class="mt">
                      <a  href="index1.php">
                          <i class="fa fa-dashboard"></i>
                          <span>Profile</span>
                      </a>
                  </li>
                <li class="mt">
                      <a href="index1.php">
                          <i class="fa fa-dashboard"></i>
                          <span>View Triggers</span>
                      </a>
                  </li>
				  