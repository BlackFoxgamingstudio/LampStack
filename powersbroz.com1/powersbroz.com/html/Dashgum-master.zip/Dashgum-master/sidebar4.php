<aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">
              
              	  <!--<p class="centered"><a href="profile.html"><img src="assets/img/ui-sam.jpg" class="img-circle" width="60"></a></p>
              	  <h5 class="centered">Marcel Newman</h5> -->
              	  	

                  <li class="centered">
                      
                          <i class="fa fa-desktop"></i>
                          <span  style="color:white;"><h3>ABOUT US </h3></span>
                      
                  </li>

									   <li class="aboutus" style="color:white;">
                      
     		
                          
	<p>&nbsp;&nbsp;&nbsp;&nbsp;We are a start-up company consisting of students who are like minded and feel extremely happy helping other people. 
	Our start-up was founded by Mr.Harish Vathan in a thirst to help young minds who belonged to National Institute of Technology, Trichy with their doubts in mathematics and 
	later on with several other subjects. Calteta was coined using "calculate" and "theta". We look forward to keep helping people, expecting nothing from our users.
    Our Mission is to Provide every sort of helping service to people around the globe for nothing! This is also a great platform for inquisitive freshers across the world to learn.</p>

<p><i><b>Impressum:</b>  Bring doubts, take back answers.</i></p>






					
               </li>
				

              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
      