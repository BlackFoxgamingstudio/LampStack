<li class="mt">
                      <a href="index3.php">
                          <i class="fa fa-dashboard"></i>
                          <span>Upload Answers</span>
                      </a>
                  </li>
				  
				  <li class="mt">
                      <a href="index3.php">
                          <i class="fa fa-dashboard"></i>
                          <span>View My Questions</span>
                      </a>
                  </li>
				