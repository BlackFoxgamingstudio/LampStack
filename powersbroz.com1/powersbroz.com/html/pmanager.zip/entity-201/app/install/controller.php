<?php

$considerations = array();

try {

    $testcon = new mysqli(DB_HOST, DB_USERNAME, DB_PASS, DB_NAME);
    if ($testcon->connect_errno == 0) {
        $connection = true;
    } else {
        $connection = false;
    }

} catch (Exception $e) {
    $connection = false;
}

if (extension_loaded('simplexml')) {
    $simplexml = true;
} else {
    $simplexml = false;
}

if (function_exists('curl_version')) {
    $curl = true;
} else {
    $curl = false;
}

if(mysqli_query($con->gate, "DESCRIBE `users`")) {
    $tables = true;
} else {
    $tables = false;
}

$php_version = explode('.', PHP_VERSION);

//var_dump($php_version);exit;

if ($php_version[0] < 5) {
    $phpPass = false;
} else {
    if ($php_version[0] >= 5 && $php_version[1] >= 4) {
        $phpPass = true;
    } else {
        $phpPass = false;
    }
}

function format_version($version) {
    $html = 'PHP v'.$version[0].'.'.$version[1];
    return $html;
}

if (function_exists('apache_get_modules')) {
    $modules = apache_get_modules();
    $rewrite = in_array('mod_rewrite', $modules);
} else {
    $rewrite =  getenv('HTTP_MOD_REWRITE')=='On' ? true : false ;
}

$considerations[] = 'Your time is currently set to the '.TIME_ZONE.' time zone';

$htaccess = file_exists('../../htaccess.txt');

if ($htaccess) {
    $considerations[] = 'You haven\'t renamed your htaccess.txt file to .htaccess';
}

if (ENVIRONMENT == 'local') {
    $considerations[] = 'According to your config.php file you are currently not in a "live" environment';
}

if (DEBUG) {
    $considerations[] = 'You are currently in DEBUG mode!';
}

if (DEMO) {
    $considerations[] = 'You are currently in DEMO mode. Please set DEMO to false in your config file.';
}