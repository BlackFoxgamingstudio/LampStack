<?php

phpinfo(); exit;