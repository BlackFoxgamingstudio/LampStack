<?php
//error_reporting(E_ALL);
require_once '../boot.php';
require_once 'controller.php';
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Entity {CC} Installation</title>
    <meta name="description" content="Entity {CC} is a PHP-based online client and project management application that is built for small businesses and freelancers. It is an online portal for you to do business and interact with your clients and third-party collaborators. Built on Bootstrap 3, Entity {CC} offers a very clean and responsive look and feel across all browsers and devices. The application is built using the popular jQuery library and HTML5 Boilerplate.">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="../../css/normalize.css">
    <link rel="stylesheet" href="../../css/bootstrap.min.css"/>
    <link rel="stylesheet" href="../../css/font-awesome.min.css"/>
    <link rel="stylesheet" href="../../css/beemuse.min.css"/>
    <link rel="stylesheet" href="../../css/animate.css"/>
    <link rel="stylesheet" href="../../css/entity.css">
    <link rel="stylesheet" href="css/install.css">
    <link href='http://fonts.googleapis.com/css?family=Fjalla+One' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Average+Sans' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>

    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../../js/vendor/jquery-1.11.2.min.js"><\/script>')</script>

</head>
<body>

    <?php require_once INCLUDES .'entity.alert.html.php'; ?>

    <div class="install-toolbar">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3">
                    <h1>Entity <span class="small">version</span> 2.0.0 - Installation</h1>
                </div>
                <div class="col-md-9">
                    <ul class="list-unstyled list-inline">
                        <li>
                            <?php if ($connection) { ?>
                            <span class="green"><i class="fa fa-check-circle"></i> Database Connection</span>
                            <?php } else { ?>
                            <span class="red"><i class="fa fa-times-circle red"></i> Database Connection</span>
                            <?php } ?>
                        </li>
                        <li>
                            <?php if ($tables) { ?>
                                <span class="green"><i class="fa fa-check-circle"></i> Database Tables</span>
                            <?php } else { ?>
                                <span class="red"><i class="fa fa-times-circle red"></i> Database Tables</span>
                            <?php } ?>
                        </li>
                        <li>
                            <?php if ($simplexml) { ?>
                                <span class="green"><i class="fa fa-check-circle"></i> SimpleXML Ext</span>
                            <?php } else { ?>
                                <span class="red"><i class="fa fa-times-circle red"></i> SimpleXML Ext</span>
                            <?php } ?>
                        </li>
                        <li>
                            <?php if ($phpPass) { ?>
                                <span class="green"><i class="fa fa-check-circle"></i> <?= format_version($php_version);?></span>
                            <?php } else { ?>
                                <span class="red"><i class="fa fa-times-circle red"></i> <?= format_version($php_version);?></span>
                            <?php } ?>
                        </li>
                        <li>
                            <?php if ($rewrite) { ?>
                                <span class="green"><i class="fa fa-check-circle"></i> Apache MOD Rewrite</span>
                            <?php } else { ?>
                                <span class="red"><i class="fa fa-times-circle red"></i> Apache MOD Rewrite</span>
                            <?php } ?>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="highlight">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="install-message">
                        <p class="push-down">All of the items in the toolbar above should be highlighted green and have a check mark next to them. Any item which is red WILL result in problems using this application.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="section">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <h2 class="text-center">Considerations based on your settings</h2>
                    <div class="normal-box">
                        <?php if (!empty($considerations)) { ?>

                            <?php foreach ($considerations as $c) { ?>
                                <p><i class="fa fa-info-circle"></i> <?= $c;?></p>
                            <?php } ?>

                        <?php } else { ?>
                            <div class="nothing-full">
                                <h3>No Considerations Popped Up! <i class="fa fa-smile-o"></i> </h3>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <h2 class="text-center">Step One: Create Administrator Account</h2>
                    <div id="createAdminAccount" class="normal-box">
                        <form id="adminAccount" action="" method="post">
                            <input type="hidden" name="create" value="admin"/>
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="firstname">First Name:</label>
                                    <input type="text" name="firstname" id="firstname" placeholder="First name"/>
                                </div>
                                <div class="col-md-6">
                                    <label for="lastname">Last Name:</label>
                                    <input type="text" name="lastname" id="lastname" placeholder="Last name"/>
                                </div>
                            </div>
                            <label for="username">Username:</label>
                            <input type="text" id="username" name="username" placeholder="Username"/>
                            <label for="email">Email Address:</label>
                            <input type="email" id="email" name="email" placeholder="Email address"/>
                            <label for="password">Password:</label>
                            <input class="push-down" type="password" id="password" name="password" placeholder="Strong password"/>
                            <button class="btn btn-success btn-block"><i class="fa fa-save"></i> Make me!</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <div class="text-center">
                        <h2>Step Two: Select your Default Currency</h2>
                        <p>You will not be able to change this later!</p>
                    </div>
                    <div id="chooseCurrency" class="normal-box">
                        <form id="systemCurrency" action="" method="post">
                            <input type="hidden" name="update" value="system-currency"/>
                            <label for="app-currency">System Currency:</label>
                            <select class="push-down" id="app-currency" name="app-currency">
                                <option value="1">United States Dollar</option>
                                <option value="2">British Pound</option>
                                <option value="3">Euro</option>
                            </select>
                            <button class="btn btn-success btn-block"><i class="fa fa-save"></i> Save</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <div class="text-center">
                        <h2>Step Three: Set Company Info</h2>
                        <p>You can change this later</p>
                    </div>
                    <div id="companyInformation" class="normal-box">
                        <form id="companyInfo" action="" method="post">
                            <input type="hidden" name="update" value="company-information"/>
                            <label for="companyname">Name of your company:</label>
                            <input class="push-down" type="text" id="companyname" name="companyname" placeholder="Company name"/>
                            <button class="btn btn-success btn-block"><i class="fa fa-save"></i> Save</button>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <div class="section-support">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h1>Need additional help?</h1>
                    <p>Email me: support@zenperfectdesign.com</p>
                </div>
            </div>
        </div>
    </div>

    <script src="../../js/entity.js"></script>

<script>
    var completeInstall = 0;
    $('#adminAccount').on('submit', function(e) {
        e.preventDefault();
        var formData = $('#adminAccount').serialize();
        $.post('./', formData, function(data) {
            if (data == 'success') {
                $('#createAdminAccount').html('<p class="alert alert-success">Account Created!</p>');
                completeInstall++;
            } else {
                entityError('Unable to Create Account', data);
            }
        });
    });

    $('#systemCurrency').on('submit', function(e) {
        e.preventDefault();
        var formData = $('#systemCurrency').serialize();
        $.post('./', formData, function(data) {
            if (data == 'success') {
                $('#chooseCurrency').html('<p class="alert alert-success">Currency Set!</p>');
                completeInstall++;
            } else {
                entityError('Unable to Set System Currency', data);
            }
        });
    });
    $('#companyInfo').on('submit', function(e) {
        e.preventDefault();
        var formData = $('#companyInfo').serialize();
        $.post('./', formData, function(data) {
            if (data == 'success') {
                $('#companyInformation').html('<p class="alert alert-success">Company Name Set</p>');
                completeInstall++;
            } else {
                entityError('Unable to Set Company Name', data);
            }
        });
    });
</script>


</body>
</html>
