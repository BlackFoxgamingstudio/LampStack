<?php

trait HasDatesTrait {

    public function created() {
        return $this->created;
    }

    public function updated() {
        return $this->updated;
    }

}