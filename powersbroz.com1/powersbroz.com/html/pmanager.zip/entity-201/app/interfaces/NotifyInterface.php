<?php

interface NotifyInterface {

    public function notify();

}