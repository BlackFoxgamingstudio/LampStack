<?php

interface Exportable {

    public function export();

    public function saveToDisk();

}