<div class="footer highlight-dark">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <p>
                    Powered by Entity {CC} version <?= $app->version; ?>, licensed to <?= $app_settings->settings['company_name'];?><br/>
                    Designed with <abbr title="LOVE"><i class="fa fa-heart"></i></abbr> by Travis Coats, Zen Perfect Design 2015
                </p>
            </div>
        </div>
    </div>
</div>
