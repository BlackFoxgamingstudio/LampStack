<div class="entity-error-container">
    <div class="entity-error-body">
        <div class="entity-error-body-content">

        </div>
        <a id="closeAlert" href="#" class="btn btn-danger push-vertical"><i class="fa fa-times"></i> Close</a>
    </div>
</div>
<div id="entity-modal-container">
    <div id="entity-modal-body">
        <div id="entity-modal-body-content">

        </div>
    </div>
</div>