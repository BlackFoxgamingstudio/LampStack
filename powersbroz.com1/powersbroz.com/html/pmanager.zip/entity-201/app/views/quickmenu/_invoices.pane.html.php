<div class="quick-menu-nothing-full">
    <h3>Coming soon</h3>
    <p>I'm working on it!</p>
</div>