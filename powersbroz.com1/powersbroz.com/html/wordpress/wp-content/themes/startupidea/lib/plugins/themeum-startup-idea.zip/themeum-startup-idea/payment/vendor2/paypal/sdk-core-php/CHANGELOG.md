
# CHANGELOG

## V2.4.3 (September 11, 2013)

   * Adding new mandatory parameters - client id & secret to open id classes
   * Adding new default scope for [Seamless checkout permission](https://developer.paypal.com/webapps/developer/docs/integration/direct/log-in-with-paypal/detailed/#seamlesscheckout) in PPOpenIdSession::getAuthorizationUrl() function

## V2.4.1 (May 20, 2013)
   * Bugfix - removing deprecated methods like setAccessToken, getAccessToken from baseService 
   * Bugfix - adding correct thirdparty auth header
   
## V2.4.0 (May 20, 2013)
   * Updating SDK to use NameSpaces
   

## V1.4.0 (April 26, 2013)
   * Adding support for Openid Connect
   

